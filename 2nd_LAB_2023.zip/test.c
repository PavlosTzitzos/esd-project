int a[1000];
int i;

int main()
{
	for (i=0;i<1000;i++){
		a[i]=1;
		
	}
	  
	
}